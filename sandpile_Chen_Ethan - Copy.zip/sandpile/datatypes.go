package main

// Board is a matrix of integers
type Board [][]int
